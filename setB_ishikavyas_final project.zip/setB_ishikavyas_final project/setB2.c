//Question2(set b)
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char x[10][100],y[10][100],s[100];
void main ()
{
	FILE *fp;
	//opening the file containing strings
	fp=fopen("setfile.txt","r");
	int num=5,q;
	scanf("%s",s);

for(int i=0;i<num;i++)
{
	fscanf(fp,"%s",x[i]);
	fscanf(fp,"%s",y[i]);
	if(strcmp(s,y[i]) == 0)
	q = i;
}
int c = 0;
for(int i=0;i<num;i++)
{
	if(strcmp(x[q],y[i]) == 0)
	c++;
}
printf("%d\n",c);
fclose(fp);
}
